
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="author" content="Appod" />
    <meta http-equiv="cache-control" content="Public, max-age=31536000">
    <meta http-equiv="Pragma" content="Public">
    <meta http-equiv="content-language" content="en-us" />
    <meta name="description" content="Appod" />
    <meta name="DC.description" content="Appod Podcast Player." />
    <meta name="keywords" content="Appod, podcast, player" />
    <meta name="DC.subject" content="Appod, podcast, player" />
    <meta name="robots" content="all" />
    <meta name="rating" content="general" />
    <meta name="DC.title" content="Appod" />
    <meta name="theme-color" content="#000000"/>
    <meta name="viewport" content="width=640, initial-scale=1.0, maximum-scale=5" />

    <!-- Jquery and Ajax Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <!-- Personal Styling -->
    <link rel="stylesheet" href="inc/style.css">
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:300,400,400i,700,900&display=swap" rel="stylesheet">

    <!-- Fontawesome -->
    <script src="https://kit.fontawesome.com/4b4ca867c1.js" crossorigin="anonymous"></script>
    <!--<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">-->


    <link rel="canonical" href="http://localhost:8888/apod"/>


    <title>Appod</title>

</head>

<body>

  <?php

  include('vendor/simplehtmldom/simple_html_dom.php');
  include('inc/database.php');


  function add_gimlet_episodes(){

    $html = file_get_html('https://gimletmedia.com/shows/heavyweight/episodes#show-tab-picker');
    $conn	= db();

    foreach($html->find('.episode-card') as $title) {
        $item_title = $title->find('.episode-title', 0)->plaintext;
        $titles[] = $item_title;
    }
    //print_r($titles);

    foreach($html->find('.episode-card') as $dateep) {
        $item_dateep = $dateep->find('.episode-date', 0)->plaintext;

        $finaldate = strtotime($item_dateep);
        $finaldate = date('Y-m-d',$finaldate);

        $dateeps[] = $finaldate;
    }
    //print_r($dateeps);

    foreach($html->find('div[class=listen-now]') as $element){
        $classurl = 'data-listen-now-player-url';
        $audiourls[] = $element->$classurl;
    }
    //print_r($audiourls);

    $arrlenght = count($titles);
    $today = date("Y-m-d");

    for($i = 0; $i < $arrlenght; $i++){

      $query	= $conn->prepare("SELECT url FROM episode WHERE url = '$audiourls[$i]' ");
      $query->execute();

      if($query->rowCount() == 0){
        $addurl	= $conn->prepare("INSERT INTO episode (title, url, date_publish, date_added, id_podcast, id_publisher, id_user, status) VALUES ('$titles[$i]', '$audiourls[$i]', '$dateeps[$i]', '$today', '1', '1', '1', '0')");
        $addurl->execute();
      }

    }

    $conn	= NULL;


  }

  //add_gimlet_episodes();

  function list_gimlet_episodes(){

    $conn	= db();
    foreach($conn->query("SELECT * FROM episode WHERE id_user = '2'") as $row) {
      $id = $row['id'];
      $url = $row['url'];
      $status = $row['status'];

      if($status == '1'){
        $bg_color = "#1BCD48";
        $opacity = "0.2";
      } elseif($status == '0'){
        $bg_color = "#111114";
        $opacity = "1";
      }


      echo '
      <div class="row justify-content-around">
        <div class="col-11 my-auto" style="opacity:'.$opacity.';" id="col_episode_'.$id.'">
          <iframe data-target="persistent-player.spotifyEmbed" src="'.$url.'" width="100%" height="152" frameborder="0" allowtransparency="true" allow="encrypted-media" style="height: 152px;" class="mt-2 test" id="'.$id.'"></iframe>
        </div>
        <div class="col-1 my-auto">
          <div class="row justify-content-center">
            <div class="status-circle status_'.$id.'" id="'.$id.'" onClick="status_switch(this.id)" style="background-color:'.$bg_color.';">
              <i class="fa-solid fa-check"></i>
            </div>
          </div>
        </div>
      </div>


      ';
      //echo '<audio controls><source src="'.$url.'" type="audio/mpeg"></audio>';

    }
    $conn	= NULL;

  }

  ?>

  <div class="container-fluid">
    <div class="row">

    </div>
    <div class="row">
      <div class="col-3 aside">

      </div>
      <div class="col-9">
        <?php list_gimlet_episodes(); ?>
      </div>
    </div>

  </div>



  <div id="log">
  </div>



<script type="text/javascript">
    function status_switch(status_id){

      var request = $.ajax({
        url: "functions.php",
        type: "POST",
        data: {id : status_id, func : 'status_switch'},
        dataType: "html"
      });

      request.done(function(msg) {
        //$("#log").html( msg );
        //alert(msg);
        if(msg == '1'){
          $(".status_"+status_id).css( "background-color", "#1BCD48" );
          $("#col_episode_"+status_id).css( "opacity", "0.2" );
        } else {
          $(".status_"+status_id).css( "background-color", "#111114" );
          $("#col_episode_"+status_id).css( "opacity", "1" );
        }


      });

      request.fail(function(jqXHR, textStatus) {
        alert( "Request failed: " + textStatus );
      });

    }
</script>


</body>
